# FastAPI Word Stream

FastAPI Word Stream est une application web qui utilise FastAPI pour créer une interface permettant de streamer des mots à partir d'un fichier CSV et d'interagir avec une base de données de mots.

## Fonctionnalités

- Streaming de mots depuis un fichier CSV
- Ajout de nouveaux mots via une API et un formulaire web
- Récupération de la liste complète des mots
- Récupération d'un mot spécifique par ID
- Gestion des erreurs personnalisée
- Middleware pour le logging des requêtes
- Vérification d'API key pour certaines routes

## Prérequis

- Python 3.8+
- Poetry

## Installation

1. Clonez le dépôt :
   ```bash
   git clone https://github.com/votre-username/fastapi-word-stream.git
   cd fastapi-word-stream
   ```

2. Installez les dépendances avec Poetry :
   ```bash
   poetry install
   ```

3. Activez l'environnement virtuel :
   ```bash
   poetry shell
   ```

## Structure du projet

```
fastapi-word-stream/
│
├── fastapi_word_stream/
│   ├── __init__.py
│   ├── main.py
│   ├── models.py
│   └── utils.py
│
├── static/
│   ├── styles.css
│   └── script.js
│
├── templates/
│   └── index.html
│
├── tests/
│   └── test_main.py
│
├── pyproject.toml
├── README.md
└── .gitignore
```

## Utilisation

1. Lancez l'application :
   ```bash
   poetry run start
   ```

2. Ouvrez votre navigateur à l'adresse `http://localhost:8000`

## API Endpoints

- `GET /` : Page d'accueil
- `GET /stream-words` : Stream de mots depuis le fichier CSV
- `POST /add-word` : Ajouter un nouveau mot (nécessite une API key)
- `GET /words` : Obtenir tous les mots
- `GET /word/{word_id}` : Obtenir un mot spécifique par ID
- `POST /submit-word` : Soumettre un nouveau mot via un formulaire

## Développement

### Tests

Exécutez les tests avec pytest :

```bash
poetry run pytest
```

### Linting

Utilisez flake8 pour le linting :

```bash
poetry run flake8 fastapi_word_stream
```

## Déploiement

Cette application peut être déployée sur diverses plateformes compatibles avec Python, telles que :

- Heroku
- DigitalOcean App Platform
- Google Cloud Run

Assurez-vous de configurer les variables d'environnement nécessaires sur votre plateforme de déploiement.

## Création d'un package pip

1. Mettez à jour la version dans `pyproject.toml`
2. Construisez le package :
   ```bash
   poetry build
   ```
3. Publiez sur PyPI :
   ```bash
   poetry publish
   ```

## Contribution

Les contributions sont les bienvenues ! Veuillez suivre ces étapes :

1. Forkez le projet
2. Créez votre branche de fonctionnalité (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Poussez vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

## Licence

Distribué sous la licence MIT. Voir `LICENSE` pour plus d'informations.

## Contact

Votre Nom - [@votre_twitter](https://twitter.com/votre_twitter) - email@example.com

Lien du projet : [https://github.com/votre-username/fastapi-word-stream](https://github.com/votre-username/fastapi-word-stream)


## Instruction généré par perplexity :

https://www.perplexity.ai/search/peut-tu-me-faire-un-code-avec-okaGzIAfRQGFVeuYTHsZ3w
