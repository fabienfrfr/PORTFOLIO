from fastapi import FastAPI, Request, Form, HTTPException, Depends
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
import csv
import asyncio
import uvicorn
from datetime import datetime
import json

app = FastAPI()

# Configuration des templates Jinja2
templates = Jinja2Templates(directory="templates")

# Configuration des fichiers statiques
app.mount("/static", StaticFiles(directory="static"), name="static")

# Chemin vers votre fichier CSV
CSV_FILE = "words.csv"

# Modèle de données pour un mot
class Word(BaseModel):
    word: str
    definition: Optional[str] = None

# Base de données simulée (pour l'exemple)
fake_db = []

# Fonction pour lire les mots du fichier CSV
def read_words_from_csv():
    with open(CSV_FILE, newline='') as csvfile:
        reader = csv.reader(csvfile)
        return [row[0] for row in reader]

# Middleware pour logger les requêtes
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = datetime.now()
    response = await call_next(request)
    process_time = (datetime.now() - start_time).total_seconds()
    print(f"Request to {request.url.path} took {process_time:.2f} seconds")
    return response

# Dépendance pour vérifier l'API key (simulation)
async def verify_api_key(api_key: str = Depends(lambda: "fake_api_key")):
    if api_key != "fake_api_key":
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return api_key

# Route pour la page d'accueil
@app.get("/")
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# Générateur asynchrone pour streamer les mots
async def word_generator():
    words = read_words_from_csv()
    for word in words:
        yield f"data: {word}\n\n"
        await asyncio.sleep(1)  # Pause d'une seconde entre chaque mot

# Route pour le flux de mots
@app.get("/stream-words")
async def stream_words():
    return StreamingResponse(word_generator(), media_type="text/event-stream")

# Route POST pour ajouter un nouveau mot
@app.post("/add-word")
async def add_word(word: Word, api_key: str = Depends(verify_api_key)):
    fake_db.append(word)
    return {"status": "success", "message": f"Word '{word.word}' added successfully"}

# Route GET pour obtenir tous les mots
@app.get("/words", response_model=List[Word])
async def get_words():
    return fake_db

# Route GET pour obtenir un mot spécifique
@app.get("/word/{word_id}")
async def get_word(word_id: int):
    if word_id < 0 or word_id >= len(fake_db):
        raise HTTPException(status_code=404, detail="Word not found")
    return fake_db[word_id]

# Route pour gérer les erreurs 404
@app.exception_handler(404)
async def custom_404_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"message": "Oops! This page doesn't exist."}
    )

# Route pour le formulaire d'ajout de mot
@app.post("/submit-word")
async def submit_word(word: str = Form(...), definition: str = Form(None)):
    new_word = Word(word=word, definition=definition)
    fake_db.append(new_word)
    return {"status": "success", "message": f"Word '{word}' added successfully"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
