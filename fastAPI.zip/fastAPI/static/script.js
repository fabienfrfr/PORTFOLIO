document.getElementById('start-stream').addEventListener('click', function() {
    const wordDisplay = document.getElementById('word-display');
    const eventSource = new EventSource('/stream-words');

    eventSource.onmessage = function(event) {
        wordDisplay.textContent = event.data;
    };

    eventSource.onerror = function(error) {
        console.error('EventSource failed:', error);
        eventSource.close();
    };
});

document.getElementById('word-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const word = document.getElementById('word').value;
    const definition = document.getElementById('definition').value;

    fetch('/submit-word', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `word=${encodeURIComponent(word)}&definition=${encodeURIComponent(definition)}`
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        document.getElementById('word-form').reset();
    })
    .catch(error => console.error('Error:', error));
});
